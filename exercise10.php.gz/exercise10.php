<?php 
$a = 20;  
$acomparar = 18; 
if($a < $acomparar) { 
    echo "Eres un menor";}
else {
    echo "Eres un adulto";
}
?>
