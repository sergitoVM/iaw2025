<?php
	$num1 = 5;
	$num2 = 10;

	echo $total = $num1 + $num2;
	echo "<br>";
	
	echo $total = $num1 . "-" . $num2 . "=" . $num1 - $num2;
	echo "<br>";
	
	echo $total = $num1 . " x " . $num2 . " = " . $num1 * $num2;
	echo "<br>";
	
	echo $total = $num1 . " / " . $num2 . " = " .$num1 / $num2;
	echo "<br>";
	
	echo $total = $num1 . " % " . $num2 . " = " .$num1 % $num2;
	echo "<br>";
	
	echo $total = $num1 . " elevado a " . $num2 . " = " .$num1 ** $num2;
	echo "<br>"
	
?>